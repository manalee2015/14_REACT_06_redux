function Header() {

	return (
		<h1>포켓몬 API 호출 연습</h1>
	);
}

export default Header;