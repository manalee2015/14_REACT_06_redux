import PokemonList from "../components/lists/PokemonList";

function Pokemons() {

	return (
		<div>
			<h1>포켓몬 도감</h1>
			<PokemonList />
		</div>
	);
}

export default Pokemons;