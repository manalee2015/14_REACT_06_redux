function Main() {

	return (
		<div>
			<h1>메인 화면</h1>
		</div>
	);
}

export default Main;