function Main() {

	return (
		<>
			<h1>메인 화면</h1>
		</>
	);
}

export default Main;