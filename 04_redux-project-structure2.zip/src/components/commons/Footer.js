function Footer() {
	return (
		<footer>
			<p>© 2024 Ohgiraffers' Restaurant. All rights reserved.</p>
		</footer>
	);
}

export default Footer;
