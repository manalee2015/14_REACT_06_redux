function Header() {
	return <header>Welcome to Ohgiraffers' Restaurant</header>;
}

export default Header;
